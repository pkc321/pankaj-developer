package com.pankaj11562.todoapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class AddToDo : AppCompatActivity() {
    lateinit var textnw:TextView
    lateinit var textinit:TextView
    lateinit var textfn:TextView
    lateinit var btns:Button
    lateinit var editnew:EditText
    lateinit var editinit:EditText
    lateinit var editfn:EditText
    private val sharedPrefFile = "kotlinsharedpreference"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_to_do)
        textnw=findViewById(R.id.newtxt)
        textinit=findViewById(R.id.oldtxt)
        textfn=findViewById(R.id.finaltxt)
        btns=findViewById(R.id.savetask)
        editnew=findViewById(R.id.tsk1input)
        editinit=findViewById(R.id.initinput)
        editfn=findViewById(R.id.finalinput)
        val sharedPreferences: SharedPreferences = this.getSharedPreferences(sharedPrefFile,
            Context.MODE_PRIVATE)
        btns.setOnClickListener{
            val intent= Intent(this,MainActivity::class.java)
            val  editone=editnew.text.toString()
            val editint=editinit.text.toString()
            val editfinal=editfn.text.toString()
            intent.putExtra("m",editone)
            intent.putExtra("n",editint)
            intent.putExtra("o",editfinal)
            startActivity(intent)
            Toast.makeText(this,"task added",Toast.LENGTH_SHORT).show()
        }
    }
}