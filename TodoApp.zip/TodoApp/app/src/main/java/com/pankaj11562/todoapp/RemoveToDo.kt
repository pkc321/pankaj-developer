package com.pankaj11562.todoapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton

class RemoveToDo : AppCompatActivity() {
    lateinit var addbtn:FloatingActionButton
    lateinit var removebtn:FloatingActionButton
    lateinit var deletebtn:FloatingActionButton
    lateinit var txtcount:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_remove_to_do)
        addbtn=findViewById(R.id.floatingActionButton)
        removebtn=findViewById(R.id.floatingActionButton3)
        deletebtn=findViewById(R.id.floatingActionButton4)
        txtcount=findViewById(R.id.txtcount)
            var x=0
        addbtn.setOnClickListener{
            x++
            txtcount.setText(x.toString())

        }
            removebtn.setOnClickListener {
                Toast.makeText(this, "remove", Toast.LENGTH_SHORT).show()

                x++
                txtcount.setText(x.toString())
        }
        deletebtn.setOnClickListener{

            x++
            txtcount.setText(x.toString())
            Toast.makeText(this,"Delete",Toast.LENGTH_SHORT).show()
        }
    }
}