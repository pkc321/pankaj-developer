package com.pankaj11562.todoapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    lateinit var RelativeLayout:RelativeLayout
    lateinit var R2:RelativeLayout
    lateinit var seekBar: SeekBar
    lateinit var textView: TextView
    lateinit var tex2:TextView
    lateinit var seek2:SeekBar
    lateinit var floatingActionButton: FloatingActionButton
    lateinit var tutorialint:TextView
    lateinit var tutorialfinal:TextView
    lateinit var forward:TextView
    lateinit var finalone:TextView
    lateinit var forward2:TextView
    lateinit var final2:TextView
    lateinit var progressbarf:ProgressBar
    lateinit var progressBar: ProgressBar
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        RelativeLayout=findViewById(R.id.lpyclick)
        R2=findViewById(R.id.ljavaclick)
        seekBar=findViewById(R.id.seekBar)
        textView=findViewById(R.id.lpython)
        tex2=findViewById(R.id.ljava)
        seek2=findViewById(R.id.seekBar3)
        floatingActionButton=findViewById(R.id.floatingActionButton2)
        tutorialint=findViewById(R.id.limit1)
        tutorialfinal=findViewById(R.id.limit2)
        forward=findViewById(R.id.forword)
        finalone=findViewById(R.id.finalv)
        forward2=findViewById(R.id.forword2)
        final2=findViewById(R.id.finalv2)
        progressbarf=findViewById(R.id.progressBar1)
        progressBar=findViewById(R.id.progressbar2)
        val m=intent.getStringExtra("m")
        textView.text=m
        val n=intent.getStringExtra("n")
        tutorialint.text=n
        val o=intent.getStringExtra("o")
        finalone.text=o
        tutorialfinal.text=n
        final2.text=o
        RelativeLayout.setOnClickListener{
//            val a= n?.toInt()
//            val b= o?.toInt()
            val intent=Intent(this,RemoveToDo::class.java)
            startActivity(intent)
        }
        R2.setOnClickListener{
            val intent=Intent(this,RemoveToDo::class.java)
            startActivity(intent)
        }
        floatingActionButton.setOnClickListener{
            val intent=Intent(this,AddToDo::class.java)
            startActivity(intent)
        }
    }
}