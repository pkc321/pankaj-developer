package com.pankaj11562.myapplication

import Fragments.*
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.FrameLayout
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {
    lateinit var drawerLayout: DrawerLayout
    lateinit var coordinatorLayout: CoordinatorLayout
    lateinit var toolbar: Toolbar
    lateinit var navigationview: NavigationView
    lateinit var frameLayout: FrameLayout
    var previousmenuitem:MenuItem?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawerLayout = findViewById(R.id.drawer)
        coordinatorLayout = findViewById(R.id.coordinator)
        toolbar = findViewById(R.id.toolbar)
        navigationview = findViewById(R.id.navigation)
        frameLayout = findViewById(R.id.frame)
        val actionBarDrawerToggle= ActionBarDrawerToggle(this,drawerLayout,
            R.string.open_drawer,
            R.string.close_drawer
        )
        setuptoolbar()
        openDashboard()
        drawerLayout.addDrawerListener(actionBarDrawerToggle)
        actionBarDrawerToggle.syncState()
        navigationview.setNavigationItemSelectedListener{
            if(previousmenuitem!=null){
                previousmenuitem?.isChecked=false
            }
            it.isCheckable=true
            it.isChecked=true
            previousmenuitem=it
            when(it.itemId){
                R.id.dashboard->{
                    openDashboard()
                    drawerLayout.closeDrawers()
                }
                R.id.straightline->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,straightline())
                        .commit()
                    supportActionBar?.title="STRAIGHT LINE"
                    drawerLayout.closeDrawers()
                }
                R.id.circle->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Circle())
                        .commit()
                    supportActionBar?.title="CIRCLE"
                    drawerLayout.closeDrawers()
                }
                R.id.parabola->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,PEH())
                        .commit()
                    supportActionBar?.title="PARABOLA,ELLIPSE & HYPERBOLA"
                    drawerLayout.closeDrawers()
                }
                R.id.limit->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame, Limit())
                        .commit()
                    supportActionBar?.title="LIMITS"
                    drawerLayout.closeDrawers()
                }
                R.id.differentiation->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Method())
                        .commit()
                    supportActionBar?.title="METHOD OF DIFFERENTIATION"
                    drawerLayout.closeDrawers()
                }
                R.id.integration->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Integration())
                        .commit()
                    supportActionBar?.title="INTEGRATION"
                    drawerLayout.closeDrawers()
                }
                R.id.deintegration->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Dintegration())
                        .commit()
                    supportActionBar?.title="DIFINITE INTEGRATION"
                    drawerLayout.closeDrawers()
                }
                R.id.fmathematics->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,fundamental())
                        .commit()
                    supportActionBar?.title="FUNDAMENTALS"
                    drawerLayout.closeDrawers()
                }
                R.id.qequations->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Quadratic())
                        .commit()
                    supportActionBar?.title="QUADRATIC"
                    drawerLayout.closeDrawers()
                }
                R.id.series->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Sequence())
                        .commit()
                    supportActionBar?.title="SEQUENCE & SERIES"
                    drawerLayout.closeDrawers()
                }
                R.id.binomial->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Binomial())
                        .commit()
                    supportActionBar?.title="BINOMIAL"
                    drawerLayout.closeDrawers()
                }
                R.id.pc1->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,PermutationCombination())
                        .commit()
                    supportActionBar?.title="PERMUTATION"
                    drawerLayout.closeDrawers()
                }
                R.id.probability->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Probability())
                        .commit()
                    supportActionBar?.title="PROBABILITY"
                    drawerLayout.closeDrawers()
                }
                R.id.complexnumber->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Complex())
                        .commit()
                    supportActionBar?.title="COMPLEX NUMBER"
                    drawerLayout.closeDrawers()
                }
                R.id.vectors->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Vectors())
                        .commit()
                    supportActionBar?.title="VECTORS"
                    drawerLayout.closeDrawers()
                }
                R.id.dimensions->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,ThreeDimensions())
                        .commit()
                    supportActionBar?.title="3-DIMENSIONS"
                    drawerLayout.closeDrawers()
                }
                R.id.triangle->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Triangle())
                        .commit()
                    supportActionBar?.title="TRIANGLE"
                    drawerLayout.closeDrawers()
                }
                R.id.inverse->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Inverse())
                        .commit()
                    supportActionBar?.title="INVERSE"
                    drawerLayout.closeDrawers()
                }
                R.id.statistics->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Statistics())
                        .commit()
                    supportActionBar?.title="STATISTICS"
                    drawerLayout.closeDrawers()
                }
                R.id.mreasoning->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Reasoning())
                        .commit()
                    supportActionBar?.title="MATHEMATICAL REASONING"
                    drawerLayout.closeDrawers()
                }
                R.id.setrelation->{
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame,Sets())
                        .commit()
                    supportActionBar?.title="SET & RELATION"
                    drawerLayout.closeDrawers()
                }
            }
            return@setNavigationItemSelectedListener true
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == android.R.id.home) {
            drawerLayout.openDrawer(GravityCompat.START)
        }
        return super.onOptionsItemSelected(item)
    }
    fun setuptoolbar(){
        setSupportActionBar(toolbar)
        supportActionBar?.title="MATHS FORMULA"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)
    }
    fun openDashboard(){
        val dashboard= Dashboard_fragment()
        val transction=supportFragmentManager.beginTransaction()
        transction.replace(R.id.frame,dashboard)
        transction.commit()
        supportActionBar?.title="Dashboard"
        navigationview.setCheckedItem(R.id.dashboard)
    }
    override fun onBackPressed() {
        val frag=supportFragmentManager.findFragmentById(R.id.frame)
        when(frag){
            !is Dashboard_fragment ->openDashboard()
            else->super.onBackPressed()
        }
    }
}