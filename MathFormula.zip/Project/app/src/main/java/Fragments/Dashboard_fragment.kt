package Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.graphics.toColor
import com.pankaj11562.myapplication.R
import com.pdfview.PDFView

class Dashboard_fragment : Fragment() {
//    lateinit var pdfView: PDFView
    lateinit var textView: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
         val view =inflater.inflate(R.layout.fragment_dashboard_fragment, container, false)
         textView=view.findViewById(R.id.detais)
         textView.text="THIS APP WILL HELP ANYONE WHO IS PREPARING FOR COMPETATIVE AS WELL AS ENGINEERING EXAM"
         textView.currentTextColor.toColor()

//        findViewById<PDFView>(R.id.textpdf).fromAsset("straightline.pdf").show()
//         pdfView=view.findViewById<PDFView>(R.id.st1).fromAsset("straightline.pdf")
//         pdfView.show()
//        Button.setOnClickListener {
//            val intent = Intent(this.context, Maths::class.java)
//            startActivity(intent)
//        }
        return view
    }
}