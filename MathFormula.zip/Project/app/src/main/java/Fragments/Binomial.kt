package Fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.pankaj11562.myapplication.R
import com.pdfview.PDFView

class Binomial : Fragment() {
    lateinit var pdfView: PDFView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_binomial, container, false)
        pdfView=view.findViewById<PDFView?>(R.id.bin).fromAsset("binomial.pdf")
        pdfView.show()
        return view
    }
}